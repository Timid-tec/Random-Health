<p align="center">
  <a href="https://github.com/DenverCoder1/readme-typing-svg"><img src="https://readme-typing-svg.herokuapp.com?size=21&color=F7E7E5&background=F8000000&lines=Random+Health&center=true&width=500&height=50"></a>
   </p>
   
## Game Supported
- CS:GO

## ConVars
- sm_random_health_version - Random Health Version
- sm_health_value - Set how much random health is given to (i) player. (def, 14)
- sm_health_enabled - Enables the random health chance. (def, 1)

## Updates

| Version | Change-Log          |
| ------- | ------------------ |
| 4.2.0   | Added to GitHub |
